//
//  Friend.swift
//  MultipleStoryboards
//
//  Created by Milan Nankov on 11/4/14.
//  Copyright (c) 2014 myOrg. All rights reserved.
//

import Foundation
