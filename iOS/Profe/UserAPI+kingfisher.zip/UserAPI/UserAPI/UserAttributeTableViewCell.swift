//
//  UserAttributeTableViewCell.swift
//  UserAPI
//
//  Created by Miguel Berrocal Gómez on 29/01/16.
//  Copyright © 2016 HELM S.C.P. All rights reserved.
//

import UIKit

class UserAttributeTableViewCell: UITableViewCell {
    
    @IBOutlet weak var attributeTitleLabel: UILabel!
    @IBOutlet weak var attributeValueLabel: UILabel!
    
}
