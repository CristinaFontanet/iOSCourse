//: Playground - noun: a place where people can play

import UIKit


//Què imprimirà el codi de la diapo 4 (La del HOLA)? Digues el tipus de la constant algu

//var amic:String? = "Pau"
//
//if let algu = amic {
//    print("HOLA " + algu)
//}

//Diapo 4 Escenari 1. Trec el if i poso això daqui sota. Què sortira?

//var amic:String? = "Pau"
//print(amic)


//Diapo 4 Escenari 2. Canvio la primera linea per lo de sota, què sortirà?

//var amic:String?
//if let algu = amic {
//    print("HOLA " + algu)
//}

//la funció Int(“qualsevolString”) Pot fallar i per tant pot tornar un valor nil. Poso això:

//var numeroConvertit = Int("3")
//
//if let numeroUnwrapped = numeroConvertit {
//    print(numeroUnwrapped)
//}


//Què passa si a la diapo 5 em carrego el if però deixo el print i perquè. Què passa si canvio la primera linia per 

//var amic:String? = "Pau"
//
//print("EI que tal " + amic!)


//Què faig per a que això funcioni si tinc:

//Correctes:

//var amic:String? = "Pau"
//var amicDeVeritat:String = amic!
//

//var amic:String? = "Pau"
//var amicDeVeritat:String? = amic


//var amic:String? = "Pau"
//
//if let amicUnwrapped = amic {
//    var amicDeVeritat:String = amicUnwrapped
//}


//Diapo 6. canvio el amic="Pau" per

//var amic:String!
//
//amic = nil
//
//print(amic)



